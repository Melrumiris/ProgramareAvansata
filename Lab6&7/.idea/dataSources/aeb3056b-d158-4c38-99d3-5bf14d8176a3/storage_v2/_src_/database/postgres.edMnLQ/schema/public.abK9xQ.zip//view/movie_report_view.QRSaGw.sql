create view movie_report_view(id, title, release_date, duration, score, genre_id, genre_name) as
SELECT m.id,
       m.title,
       m.release_date,
       m.duration,
       m.score,
       m.genre_id,
       g.name AS genre_name
FROM movies m
         JOIN genres g ON g.id = m.genre_id;

alter table movie_report_view
    owner to postgres;

